# Apache Cordova Tutorial

In this tutorial, you will learn strategies and best practices to build native-like mobile applications with HTML, JavaScript, and CSS. You will build an Apache Cordova (aka PhoneGap) Employee Directory application from scratch using the Single Page Architecture, HTML templates, touch events, and performance optimization techniques.

Follow the step-by-step instructions available here: http://ccoenraets.github.io/cordova-tutorial/
